# 《DeepSeek Harness 应用开发实践》全书 Markdown

版本：1.0.0　提交：50a780f
导出时间：2026-09-21T03:13:50.635Z

本压缩包包含：
- `deepseek-harness-in-practice.md` —— 全书合并 Markdown（含 YAML frontmatter 已剥离）
- `README.md` —— 本说明

在线阅读：https://guotao0628.github.io/shutongbuddy/
问题反馈：https://github.com/guotao0628/shutongbuddy/issues

文档采用 CC BY 4.0 许可，代码采用 MIT 许可。
